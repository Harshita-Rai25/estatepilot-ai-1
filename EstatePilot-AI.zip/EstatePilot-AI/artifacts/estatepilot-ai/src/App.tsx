import { type FormEvent, type ReactNode, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  Activity as ActivityIcon, AlertCircle, ArrowDownRight, ArrowRight, ArrowUpRight,
  BedDouble, Building2, CalendarDays, Check, CheckCircle2, ChevronDown, CircleHelp,
  Headset, Home, LayoutDashboard, MapPin, Menu, MessageSquareText, Search,
  RefreshCw, Send, ShieldCheck, SlidersHorizontal, Sparkles, UserRound, Users, X,
} from 'lucide-react';
import {
  useHealthCheck, useListProperties, useSendAssistantMessage,
  useListLeads, useCreateLead, useListBookings, useCreateBooking, useUpdateBooking,
  useListTickets, useCreateTicket, useUpdateTicket, useEscalateTicket,
  useGetDashboardSummary, useListActivity,
  getListLeadsQueryKey, getListBookingsQueryKey,
  getListTicketsQueryKey, getGetDashboardSummaryQueryKey, getListActivityQueryKey,
} from '@workspace/api-client-react';
import type { Property, LeadInput, BookingInput, TicketInput } from '@workspace/api-client-react';
import { Route, Switch, Link, useLocation, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const links = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/properties', label: 'Properties', icon: Building2 },
  { href: '/assistant', label: 'Demo assistant', icon: Sparkles },
  { href: '/leads', label: 'Leads', icon: Users },
  { href: '/bookings', label: 'Visit requests', icon: CalendarDays },
  { href: '/support', label: 'Support', icon: Headset },
  { href: '/activity', label: 'Activity', icon: ActivityIcon },
];

function dateLabel(value?: string) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric' }).format(date);
}
function todayLabel() {
  return new Intl.DateTimeFormat('en', { weekday: 'long', month: 'long', day: 'numeric' }).format(new Date()).toUpperCase();
}
function money(value?: number | null) {
  return value == null ? 'Not specified' : new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value);
}
function shortDate(value?: string) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? value : new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(d);
}

function Shell({ children }: { children: ReactNode }) {
  const [path] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const health = useHealthCheck();
  return <div className="app-shell min-h-[100dvh]">
    <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
      <Link href="/" className="brand" data-testid="link-brand">
        <span className="brand-mark"><Building2 size={19} strokeWidth={2.3} /></span>
        <span className="brand-name">estatepilot<span>AI</span></span>
      </Link>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="side-nav" aria-label="Main navigation">
        {links.map(({ href, label, icon: Icon }) => <Link href={href} key={href} onClick={() => setMobileOpen(false)} className={`nav-link ${path === href ? 'nav-active' : ''}`} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}>
          <Icon size={18} strokeWidth={1.8} /><span>{label}</span>{href === '/support' && <span className="nav-dot" />}
        </Link>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-prompt"><span className="prompt-icon"><ShieldCheck size={17} /></span><div><strong>Operations, in good hands.</strong><p>One clear view of every customer conversation.</p></div></div>
        <div className="agent-profile"><div className="profile-avatar">EP</div><div className="profile-info"><strong>EstatePilot team</strong><span>Operations workspace</span></div><ChevronDown size={15} /></div>
      </div>
    </aside>
    {mobileOpen && <button aria-label="Close navigation" className="mobile-scrim" onClick={() => setMobileOpen(false)} data-testid="button-close-menu" />}
    <main className="main-area">
      <header className="topbar">
        <button className="mobile-menu icon-button" aria-label="Open navigation" onClick={() => setMobileOpen(true)} data-testid="button-open-menu"><Menu size={20} /></button>
        <div className="crumb"><span>EstatePilot</span><span className="crumb-slash">/</span><strong>{links.find(l => l.href === path)?.label ?? 'Workspace'}</strong></div>
        <div className="topbar-right">
          <div className={`connection ${health.isError ? 'connection-error' : ''}`} data-testid="status-api-health"><span className="connection-dot" />{health.isLoading ? 'Checking system' : health.isError ? 'System unavailable' : 'System operational'}</div>
          <div className="top-avatar">EP</div>
        </div>
      </header>
      <section className="page-wrap">{children}</section>
      <footer className="page-footer"><span>EstatePilot AI <span className="footer-sep">·</span> Every inquiry becomes an opportunity.</span><span>Demo workspace <span className="footer-sep">·</span> Fictional listings</span></footer>
    </main>
  </div>;
}

function PageTitle({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description: string; action?: ReactNode }) {
  return <div className="page-heading animate-rise"><div><div className="eyebrow">{eyebrow ?? 'OPERATIONS'}</div><h1>{title}</h1><p>{description}</p></div>{action && <div className="heading-action">{action}</div>}</div>;
}
function Panel({ children, className = '' }: { children: ReactNode; className?: string }) { return <section className={`panel ${className}`}>{children}</section>; }
function PanelHeading({ title, detail, action }: { title: string; detail?: string; action?: ReactNode }) {
  return <div className="panel-heading"><div><h2>{title}</h2>{detail && <p>{detail}</p>}</div>{action}</div>;
}
function QueryState({ loading, error, retry, children, empty, hasData = true }: { loading: boolean; error: boolean; retry: () => void; children: ReactNode; empty?: ReactNode; hasData?: boolean }) {
  if (loading) return <div className="skeleton-stack" aria-label="Loading"><div className="skeleton skeleton-title" /><div className="skeleton" /><div className="skeleton" /></div>;
  if (error) return <div className="state-box"><div className="state-icon state-error"><AlertCircle size={19} /></div><strong>We couldn’t load this view</strong><p>Check your connection, then try again.</p><button className="button button-secondary button-small" onClick={retry} data-testid="button-retry">Try again</button></div>;
  if (!hasData && empty) return <>{empty}</>;
  return <>{children}</>;
}
function EmptyState({ icon: Icon = CircleHelp, title, copy, action }: { icon?: typeof CircleHelp; title: string; copy: string; action?: ReactNode }) {
  return <div className="empty-state"><div className="empty-icon"><Icon size={21} /></div><strong>{title}</strong><p>{copy}</p>{action}</div>;
}
function StatCard({ label, value, hint, icon: Icon, tone, trend }: { label: string; value: number | string; hint: string; icon: typeof Users; tone: string; trend?: string }) {
  return <div className="stat-card animate-rise"><div className={`stat-icon ${tone}`}><Icon size={19} /></div><div className="stat-label">{label}</div><div className="stat-value" data-testid={`value-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</div><div className="stat-foot">{trend && <span className="stat-trend"><ArrowUpRight size={13} />{trend}</span>}{hint}</div></div>;
}
function StatusPill({ children, tone }: { children: ReactNode; tone?: string }) { return <span className={`status-pill ${tone ?? ''}`}>{children}</span>; }
function useRefresh() {
  const qc = useQueryClient();
  return () => {
    void qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    void qc.invalidateQueries({ queryKey: getListLeadsQueryKey() });
    void qc.invalidateQueries({ queryKey: getListBookingsQueryKey() });
    void qc.invalidateQueries({ queryKey: getListTicketsQueryKey() });
    void qc.invalidateQueries({ queryKey: getListActivityQueryKey() });
  };
}

function Overview() {
  const qc = useQueryClient();
  const summary = useGetDashboardSummary();
  const bookings = useListBookings();
  const tickets = useListTickets();
  const activity = useListActivity({ limit: 5 });
  const refresh = () => {
    void qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    void qc.invalidateQueries({ queryKey: getListBookingsQueryKey() });
    void qc.invalidateQueries({ queryKey: getListTicketsQueryKey() });
    void qc.invalidateQueries({ queryKey: getListActivityQueryKey({ limit: 5 }) });
  };
  const latestBookings = (bookings.data ?? []).slice(0, 4);
  const latestActivity = (activity.data ?? []).slice(0, 4);
  return <>
    <PageTitle eyebrow={todayLabel()} title="Good morning, team." description="Here’s what’s moving across your customer operations today." action={<Link href="/assistant" className="button button-primary" data-testid="link-open-assistant"><Sparkles size={16} />Try the assistant<ArrowRight size={15} /></Link>} />
    <div className="overview-banner animate-rise delay-1"><div className="banner-copy"><span className="banner-kicker"><span className="banner-spark"><Sparkles size={14} /></span> THE CUSTOMER JOURNEY, IN ONE PLACE</span><h2>Every inquiry becomes<br className="desktop-only" /> an opportunity.</h2><p>From the first property question to a visit request, keep every next step in view.</p><Link href="/properties" className="banner-link" data-testid="link-explore-properties">Explore demo properties <ArrowRight size={15} /></Link></div><div className="banner-graphic" aria-hidden="true"><div className="graphic-orbit orbit-one" /><div className="graphic-orbit orbit-two" /><div className="graphic-house"><Home size={43} strokeWidth={1.25} /></div><span className="graphic-chip chip-lead"><Users size={14} />New inquiry</span><span className="graphic-chip chip-visit"><CalendarDays size={14} />Visit requested</span><span className="graphic-node node-one" /><span className="graphic-node node-two" /><span className="graphic-node node-three" /></div></div>
    <div className="section-row"><div><div className="eyebrow">YOUR SNAPSHOT</div><h2 className="section-title">The day at a glance</h2></div><div className="section-tools"><span className="updated-label"><span className="live-indicator" />Live workspace data</span><button className="refresh-button" onClick={refresh} data-testid="button-refresh-dashboard"><RefreshCw size={13} />Refresh</button></div></div>
    <QueryState loading={summary.isLoading} error={summary.isError} retry={refresh} hasData={!!summary.data}>
      {summary.data && <div className="stats-grid">
        <StatCard label="Total leads" value={summary.data.totalLeads} hint="Saved customer inquiries" icon={Users} tone="teal" trend="All time" />
        <StatCard label="Visit requests" value={summary.data.visitRequests} hint="Property visits to coordinate" icon={CalendarDays} tone="blue" trend="All time" />
        <StatCard label="Open tickets" value={summary.data.openTickets} hint="Customer cases in progress" icon={MessageSquareText} tone="amber" />
        <StatCard label="Escalated cases" value={summary.data.escalatedCases} hint="Requiring a human response" icon={Headset} tone="coral" />
      </div>}
    </QueryState>
    <div className="overview-columns">
      <Panel className="animate-rise delay-2"><PanelHeading title="Latest visit requests" detail="The next step for interested buyers" action={<Link href="/bookings" className="text-link" data-testid="link-all-bookings">View all <ArrowRight size={14} /></Link>} />
        <QueryState loading={bookings.isLoading} error={bookings.isError} retry={refresh} hasData={latestBookings.length > 0} empty={<EmptyState icon={CalendarDays} title="No visit requests yet" copy="When a customer requests a property visit, it will show up here." action={<Link href="/assistant" className="button button-soft button-small" data-testid="link-start-customer-journey">Open demo assistant</Link>} />}>
          <div className="compact-list">{latestBookings.map(b => <div className="compact-row" key={b.id} data-testid={`booking-row-${b.id}`}><div className="row-avatar row-teal"><CalendarDays size={16} /></div><div className="row-main"><strong>{b.name}</strong><span>{dateLabel(b.preferredDate)} · {b.preferredTime}</span></div><StatusPill tone={b.status === 'confirmed' ? 'pill-green' : b.status === 'cancelled' ? 'pill-muted' : 'pill-gold'}>{b.status}</StatusPill></div>)}</div>
        </QueryState>
      </Panel>
      <Panel className="animate-rise delay-3"><PanelHeading title="Recent activity" detail="A trace of customer actions" action={<Link href="/activity" className="text-link" data-testid="link-all-activity">Timeline <ArrowRight size={14} /></Link>} />
        <QueryState loading={activity.isLoading} error={activity.isError} retry={refresh} hasData={latestActivity.length > 0} empty={<EmptyState icon={ActivityIcon} title="Your timeline starts here" copy="Saved inquiries, visit requests, and support actions will appear here." />}>
          <div className="activity-list">{latestActivity.map((a, i) => <div className="activity-item" key={a.id} data-testid={`activity-row-${a.id}`}><div className={`activity-marker ${a.outcome === 'failed' ? 'marker-fail' : ''}`}>{a.outcome === 'failed' ? <AlertCircle size={13} /> : <Check size={13} />}</div><div className="activity-body"><strong>{a.description}</strong><span>{a.eventType} <i>·</i> {dateLabel(a.createdAt)}</span></div></div>)}</div>
        </QueryState>
      </Panel>
    </div>
    <div className="bottom-note"><ShieldCheck size={15} /><span>Built for follow-through. Customer data stays in your operations workspace.</span><Link href="/support" data-testid="link-support-note">Visit support <ArrowRight size={13} /></Link></div>
  </>;
}

function Properties() {
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [budget, setBudget] = useState('');
  const [bedrooms, setBedrooms] = useState('');
  const params = useMemo(() => ({ ...(search ? { location: search } : {}), ...(type ? { propertyType: type } : {}), ...(budget ? { maxBudget: Number(budget) } : {}), ...(bedrooms ? { bedrooms: Number(bedrooms) } : {}) }), [search, type, budget, bedrooms]);
  const propsQuery = useListProperties(params);
  const results = propsQuery.data ?? [];
  return <>
    <PageTitle eyebrow="PROPERTY CATALOG" title="Find the right fit." description="Explore fictional demo listings and guide customers toward a clear next step." action={<span className="fiction-badge"><ShieldCheck size={14} />All listings are fictional</span>} />
    <div className="filter-panel">
      <label className="search-field"><Search size={17} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by neighborhood or city" aria-label="Search location" data-testid="input-property-search" /><kbd>/</kbd></label>
      <label className="select-field"><SlidersHorizontal size={15} /><select value={type} onChange={e => setType(e.target.value)} aria-label="Property type" data-testid="select-property-type"><option value="">All property types</option><option>Apartment</option><option>Condo</option><option>Townhouse</option><option>Single-family</option><option>Villa</option></select></label>
      <label className="select-field budget-field"><span>$</span><select value={budget} onChange={e => setBudget(e.target.value)} aria-label="Maximum budget" data-testid="select-property-budget"><option value="">Any budget</option><option value="500000">Up to $500k</option><option value="750000">Up to $750k</option><option value="1000000">Up to $1m</option><option value="1500000">Up to $1.5m</option></select></label>
      <label className="select-field"><BedDouble size={15} /><select value={bedrooms} onChange={e => setBedrooms(e.target.value)} aria-label="Minimum bedrooms" data-testid="select-property-bedrooms"><option value="">Any bedrooms</option><option value="1">1+ bedrooms</option><option value="2">2+ bedrooms</option><option value="3">3+ bedrooms</option><option value="4">4+ bedrooms</option></select></label>
    </div>
    <div className="results-row"><span><strong>{results.length}</strong> demo properties</span><span className="result-label">Curated for customer discovery</span></div>
    <QueryState loading={propsQuery.isLoading} error={propsQuery.isError} retry={() => void propsQuery.refetch()} hasData={results.length > 0} empty={<EmptyState icon={Building2} title="No properties match those filters" copy="Try a broader location or clear your filters to see all fictional demo listings." action={<button className="button button-secondary button-small" onClick={() => { setSearch(''); setBudget(''); setType(''); setBedrooms(''); }} data-testid="button-clear-filters">Clear filters</button>} />}>
      <div className="property-grid">{results.map((property, i) => <PropertyCard key={property.id} property={property} index={i} />)}</div>
    </QueryState>
  </>;
}
const propertyPalettes = ['property-art-a', 'property-art-b', 'property-art-c', 'property-art-d', 'property-art-e', 'property-art-f'];
function PropertyCard({ property: p, index }: { property: Property; index: number }) {
  return <article className={`property-card animate-rise ${index % 3 === 1 ? 'delay-1' : index % 3 === 2 ? 'delay-2' : ''}`} data-testid={`card-property-${p.id}`}>
    <div className={`property-art ${propertyPalettes[index % propertyPalettes.length]}`}><div className="art-sky"><div className="art-sun" /><div className="art-cloud cloud-a" /><div className="art-cloud cloud-b" /></div><div className="art-landscape"><div className="art-building"><div className="art-roof" /><div className="art-windows"><i /><i /><i /><i /><i /><i /><i /><i /></div></div><div className="art-tree tree-one" /><div className="art-tree tree-two" /><div className="art-ground" /></div><span className="property-fiction-tag">DEMO LISTING</span><span className="property-type-tag">{p.propertyType}</span></div>
    <div className="property-info"><div className="property-price">{money(p.price)}</div><h3>{p.title}</h3><div className="property-location"><MapPin size={14} />{p.location}</div><div className="property-meta"><span><BedDouble size={15} />{p.bedrooms} bedrooms</span><span><span className="availability-dot" />{p.availability}</span></div><p>{p.description}</p><div className="property-actions"><Link href={`/assistant?property=${encodeURIComponent(p.id)}`} className="button button-primary button-small" data-testid={`link-ask-about-${p.id}`}>Ask about this home<ArrowRight size={14} /></Link><span className="fictional-label">Fictional</span></div></div>
  </article>;
}

function Assistant() {
  const [, setLocation] = useLocation();
  const send = useSendAssistantMessage();
  const createLead = useCreateLead();
  const createBooking = useCreateBooking();
  const propsQuery = useListProperties();
  const refresh = useRefresh();
  const [message, setMessage] = useState(() => {
    const propertyId = new URLSearchParams(window.location.search).get('property');
    return propertyId ? `Tell me about ${propertyId}` : '';
  });
  const [lastSentMessage, setLastSentMessage] = useState('');
  const [reply, setReply] = useState<null | { reply: string; matchedProperties: Property[]; followUpQuestion: string | null; suggestions: string[]; mode: string }>(null);
  const [leadProp, setLeadProp] = useState<Property | null>(null);
  const [bookingProp, setBookingProp] = useState<Property | null>(null);
  const [notice, setNotice] = useState('');
  const [formError, setFormError] = useState('');
  function onSend(e: FormEvent) {
    e.preventDefault();
    if (!message.trim()) return;
    setFormError(''); setNotice('');
    const submitted = message.trim();
    send.mutate({ data: { message: submitted } }, { onSuccess: result => { setReply(result); setLastSentMessage(submitted); setMessage(''); }, onError: () => setFormError('The assistant could not respond. Please try again.') });
  }
  function chooseSuggestion(suggestion: string) {
    if (/support ticket/i.test(suggestion)) {
      setLocation('/support?new=1');
      return;
    }
    setMessage(suggestion);
  }
  function onLead(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setFormError('');
    const fd = new FormData(e.currentTarget);
    const data: LeadInput = { name: String(fd.get('name')), phone: String(fd.get('phone')), email: String(fd.get('email') || '') || null, preferredLocation: String(fd.get('location') || leadProp?.location || 'Not specified'), budget: fd.get('budget') ? Number(fd.get('budget')) : null, propertyInterest: leadProp?.title ?? null };
    createLead.mutate({ data }, { onSuccess: () => { setNotice('Inquiry saved successfully. The customer is now in your leads.'); setLeadProp(null); refresh(); }, onError: () => setFormError('We couldn’t save this inquiry. Please review the details and retry.') });
  }
  function onBooking(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setFormError('');
    const fd = new FormData(e.currentTarget);
    const data: BookingInput = { name: String(fd.get('name')), phone: String(fd.get('phone')), email: String(fd.get('email') || '') || null, propertyId: bookingProp!.id, preferredDate: String(fd.get('date')), preferredTime: String(fd.get('time')) };
    createBooking.mutate({ data }, { onSuccess: result => { setNotice(`Visit request ${result.status === 'confirmed' ? 'confirmed' : 'submitted as requested'}.`); setBookingProp(null); refresh(); }, onError: () => setFormError('The visit request could not be saved. Please try again.') });
  }
  const suggestions = ['Show me homes in the city', 'I’m looking for a 2-bedroom', 'What can I find under $750k?'];
  return <>
    <PageTitle eyebrow="CUSTOMER EXPERIENCE" title="A better first conversation." description="Try the rule-based demo assistant, then save a real inquiry or visit request." action={<span className="demo-indicator"><span />DEMO MODE</span>} />
    <div className="assistant-layout">
      <section className="chat-panel">
        <div className="chat-header"><div className="assistant-avatar"><Sparkles size={18} /></div><div><strong>EstatePilot property assistant</strong><span><span className="online-dot" />Rule-based demo · fictional listings only</span></div><div className="demo-tag">DEMO</div></div>
        <div className="chat-content">
          <div className="chat-date">A CUSTOMER CONVERSATION</div>
          <div className="chat-message assistant-message"><div className="assistant-avatar avatar-small"><Sparkles size={13} /></div><div className="message-bubble"><p>Hello. I can help explore our fictional demo properties. What kind of home or location are you looking for?</p><span>EstatePilot assistant · demo</span></div></div>
          {reply && <><div className="chat-message user-message"><div className="message-bubble"><p>{lastSentMessage}</p><span>Just now</span></div><div className="user-avatar"><UserRound size={14} /></div></div><div className="chat-message assistant-message"><div className="assistant-avatar avatar-small"><Sparkles size={13} /></div><div className="message-bubble"><p>{reply.reply}</p>{reply.followUpQuestion && <p className="follow-up-question">{reply.followUpQuestion}</p>}<span>Rule-based demo · {reply.mode}</span></div></div></>}
          {reply?.matchedProperties?.length ? <div className="matched-properties"><div className="matched-title">{reply.matchedProperties.length} properties to explore</div>{reply.matchedProperties.map(p => <div className="match-row" key={p.id}><div className="match-mark"><Home size={16} /></div><div className="match-main"><strong>{p.title}</strong><span>{p.location} · {p.bedrooms} bed</span></div><strong className="match-price">{money(p.price)}</strong><div className="match-actions"><button className="button button-soft button-small" onClick={() => setLeadProp(p)} data-testid={`button-save-inquiry-${p.id}`}>Save inquiry</button><button className="button button-primary button-small" onClick={() => setBookingProp(p)} data-testid={`button-request-visit-${p.id}`}>Request visit</button></div></div>)}</div> : null}
          {(reply?.suggestions?.length ? reply.suggestions : suggestions).length > 0 && <div className="suggestion-row">{(reply?.suggestions?.length ? reply.suggestions : suggestions).map(s => <button key={s} className="suggestion-chip" onClick={() => chooseSuggestion(s)} data-testid={`button-suggestion-${s.slice(0, 12).toLowerCase().replaceAll(' ', '-')}`}>{s}<ArrowUpRight size={12} /></button>)}</div>}
        </div>
        <form className="chat-compose" onSubmit={onSend}><input value={message} onChange={e => setMessage(e.target.value)} placeholder="Ask about locations, budgets, or home types..." maxLength={2000} aria-label="Message the demo assistant" data-testid="input-assistant-message" /><button className="send-button" type="submit" disabled={send.isPending || !message.trim()} aria-label="Send message" data-testid="button-send-assistant">{send.isPending ? <span className="button-loader" /> : <Send size={17} />}</button></form>
        <div className="chat-footnote">Rule-based demo only. No live AI, integrations, or notifications are connected.</div>
      </section>
      <aside className="assistant-aside"><Panel className="next-step-panel"><div className="next-step-icon"><ArrowDownRight size={18} /></div><div className="eyebrow">A CONVERSATION THAT GOES SOMEWHERE</div><h3>One simple next step.</h3><p>Save a real inquiry or request a property visit. Every action is submitted to your operations workspace.</p><div className="step-list"><div><span>01</span><strong>Discover a home</strong></div><div><span>02</span><strong>Save the inquiry</strong></div><div><span>03</span><strong>Coordinate a visit</strong></div></div></Panel>
        <Panel className="note-panel"><div className="note-icon"><ShieldCheck size={17} /></div><div><strong>Real actions, demo listings</strong><p>Leads and visit requests are saved through the connected API. All properties shown are fictional.</p></div></Panel>
      </aside>
    </div>
    {send.isError && <InlineAlert text={formError} />}
    {notice && <InlineSuccess text={notice} />}
    {formError && !send.isError && <InlineAlert text={formError} />}
    {propsQuery.isError && <InlineAlert text="Property catalog unavailable. Assistant suggestions may not include listings." />}
    {leadProp && <FormModal title="Save customer inquiry" subtitle={`Interested in ${leadProp.title}`} close={() => { setLeadProp(null); setFormError(''); }}><form className="modal-form" onSubmit={onLead}><Field label="Customer name" name="name" required placeholder="Full name" /><Field label="Phone number" name="phone" required placeholder="+1 (555) 000-0000" /><Field label="Email address" name="email" type="email" placeholder="name@example.com" /><Field label="Preferred location" name="location" defaultValue={leadProp.location} required placeholder="Neighborhood or city" /><Field label="Budget" name="budget" type="number" placeholder="Maximum budget" /><div className="modal-foot"><button type="button" className="button button-secondary" onClick={() => setLeadProp(null)} data-testid="button-cancel-lead">Cancel</button><button className="button button-primary" disabled={createLead.isPending} data-testid="button-submit-lead">{createLead.isPending ? 'Saving…' : 'Save inquiry'}</button></div></form>{createLead.isError && <InlineAlert text="We couldn’t save this inquiry. Please try again." />}</FormModal>}
    {bookingProp && <FormModal title="Request a property visit" subtitle={`${bookingProp.title} · ${bookingProp.location}`} close={() => { setBookingProp(null); setFormError(''); }}><form className="modal-form" onSubmit={onBooking}><Field label="Customer name" name="name" required placeholder="Full name" /><Field label="Phone number" name="phone" required placeholder="+1 (555) 000-0000" /><Field label="Email address" name="email" type="email" placeholder="name@example.com" /><Field label="Preferred date" name="date" type="date" required /><label className="field-label">Preferred time<select name="time" required defaultValue="" data-testid="select-visit-time"><option value="" disabled>Select a preferred time</option><option>Morning</option><option>Afternoon</option><option>Evening</option></select></label><div className="modal-help">This creates a visit request. It is not confirmed unless the API returns a confirmed status.</div><div className="modal-foot"><button type="button" className="button button-secondary" onClick={() => setBookingProp(null)} data-testid="button-cancel-booking">Cancel</button><button className="button button-primary" disabled={createBooking.isPending} data-testid="button-submit-booking">{createBooking.isPending ? 'Submitting…' : 'Request visit'}</button></div></form>{createBooking.isError && <InlineAlert text="We couldn’t submit this visit request. Please try again." />}</FormModal>}
  </>;
}
function Field({ label, name, type = 'text', required = false, placeholder = '', defaultValue = '' }: { label: string; name: string; type?: string; required?: boolean; placeholder?: string; defaultValue?: string }) {
  return <label className="field-label">{label}<input name={name} type={type} required={required} placeholder={placeholder} defaultValue={defaultValue} data-testid={`input-${name}`} /></label>;
}
function FormModal({ title, subtitle, close, children }: { title: string; subtitle: string; close: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) close(); }}><div className="modal-card" role="dialog" aria-modal="true" aria-label={title}><div className="modal-header"><div><div className="eyebrow">CUSTOMER OPERATIONS</div><h2>{title}</h2><p>{subtitle}</p></div><button className="icon-button" onClick={close} aria-label="Close dialog" data-testid="button-close-modal"><X size={18} /></button></div>{children}</div></div>;
}
function InlineAlert({ text }: { text: string }) { return <div className="inline-alert" role="alert" data-testid="status-action-error"><AlertCircle size={15} />{text}</div>; }
function InlineSuccess({ text }: { text: string }) { return <div className="inline-success" role="status" data-testid="status-action-success"><CheckCircle2 size={15} />{text}</div>; }

function Leads() {
  const query = useListLeads();
  const [search, setSearch] = useState('');
  const list = (query.data ?? []).filter(l => `${l.name} ${l.phone} ${l.email ?? ''} ${l.preferredLocation} ${l.propertyInterest ?? ''}`.toLowerCase().includes(search.toLowerCase()));
  return <>
    <PageTitle eyebrow="CUSTOMER RELATIONSHIPS" title="Leads that have a next step." description="Every saved inquiry, ready for your team to follow up." action={<span className="count-badge"><Users size={15} />{query.data?.length ?? '—'} total leads</span>} />
    <div className="list-toolbar"><label className="search-field"><Search size={17} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name, phone, or location" aria-label="Search leads" data-testid="input-lead-search" /><kbd>/</kbd></label><span className="toolbar-hint">Recently added first</span></div>
    <Panel className="table-panel"><QueryState loading={query.isLoading} error={query.isError} retry={() => void query.refetch()} hasData={list.length > 0} empty={<EmptyState icon={Users} title={search ? 'No leads match your search' : 'Your first opportunity starts here'} copy={search ? 'Try a different name, phone number, or location.' : 'When a customer saves an inquiry in the demo assistant, it will appear here.'} action={search ? <button className="button button-secondary button-small" onClick={() => setSearch('')} data-testid="button-clear-lead-search">Clear search</button> : <Link href="/assistant" className="button button-primary button-small" data-testid="link-create-first-lead"><Sparkles size={14} />Try the demo assistant</Link>} />}>
      <div className="table-scroll"><table><thead><tr><th>Customer</th><th>Preferred area</th><th>Property interest</th><th>Budget</th><th>Added</th></tr></thead><tbody>{list.map(l => <tr key={l.id} data-testid={`lead-row-${l.id}`}><td><div className="table-person"><div className="person-initials">{l.name.split(' ').map(w => w[0]).slice(0,2).join('').toUpperCase()}</div><div><strong data-testid={`text-lead-name-${l.id}`}>{l.name}</strong><span>{l.email || l.phone}</span></div></div></td><td><span className="table-location"><MapPin size={14} />{l.preferredLocation}</span></td><td>{l.propertyInterest || <span className="muted-cell">Not specified</span>}</td><td>{money(l.budget)}</td><td>{shortDate(l.createdAt)}</td></tr>)}</tbody></table></div>
    </QueryState></Panel>
  </>;
}

function Bookings() {
  const qc = useQueryClient();
  const query = useListBookings();
  const update = useUpdateBooking();
  const [filter, setFilter] = useState('all');
  const [error, setError] = useState('');
  const rows = (query.data ?? []).filter(b => filter === 'all' || b.status === filter);
  const refresh = () => { void qc.invalidateQueries({ queryKey: getListBookingsQueryKey() }); void qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); void qc.invalidateQueries({ queryKey: getListActivityQueryKey() }); };
  function change(id: number, status: 'confirmed' | 'cancelled') {
    setError('');
    update.mutate({ bookingId: id, data: { status } }, { onSuccess: refresh, onError: () => setError('The visit request could not be updated. Please retry.') });
  }
  return <>
    <PageTitle eyebrow="VISIT COORDINATION" title="Visit requests." description="Customer-preferred dates are requests, not calendar appointments. Confirm or cancel them here." action={<Link href="/assistant" className="button button-primary" data-testid="link-new-visit-request"><CalendarDays size={16} />Request a visit</Link>} />
    {error && <InlineAlert text={error} />}
    <div className="filter-tabs" role="tablist" aria-label="Filter visit requests">{['all','requested','confirmed','cancelled'].map(f => <button key={f} className={filter === f ? 'filter-tab active-tab' : 'filter-tab'} onClick={() => setFilter(f)} data-testid={`button-filter-booking-${f}`}>{f === 'all' ? 'All requests' : f[0].toUpperCase() + f.slice(1)}<span>{f === 'all' ? query.data?.length ?? 0 : (query.data ?? []).filter(b => b.status === f).length}</span></button>)}</div>
    <Panel className="table-panel"><QueryState loading={query.isLoading} error={query.isError} retry={() => void query.refetch()} hasData={rows.length > 0} empty={<EmptyState icon={CalendarDays} title={filter === 'all' ? 'No visit requests yet' : `No ${filter} requests`} copy="When a customer submits a visit request, it will be listed here for your team." action={<Link href="/assistant" className="button button-soft button-small" data-testid="link-assistant-bookings">Open demo assistant</Link>} />}>
      <div className="table-scroll"><table className="booking-table"><thead><tr><th>Customer</th><th>Property</th><th>Preferred visit</th><th>Status</th><th>Actions</th></tr></thead><tbody>{rows.map(b => <tr key={b.id} data-testid={`booking-row-${b.id}`}><td><div className="table-person"><div className="person-initials">{b.name.split(' ').map(w => w[0]).slice(0,2).join('').toUpperCase()}</div><div><strong>{b.name}</strong><span>{b.phone}{b.email ? ` · ${b.email}` : ''}</span></div></div></td><td><div className="booking-property"><strong>{b.propertyId}</strong><small>Requested {dateLabel(b.createdAt)}</small></div></td><td><strong className="cell-primary">{dateLabel(b.preferredDate)}</strong><span className="cell-subtle">{b.preferredTime}</span></td><td><StatusPill tone={b.status === 'confirmed' ? 'pill-green' : b.status === 'cancelled' ? 'pill-muted' : 'pill-gold'}>{b.status}</StatusPill></td><td><div className="table-actions">{b.status === 'requested' ? <><button className="button button-soft button-small" disabled={update.isPending} onClick={() => change(b.id, 'confirmed')} data-testid={`button-confirm-booking-${b.id}`}><Check size={13} />Confirm</button><button className="text-action text-danger" disabled={update.isPending} onClick={() => change(b.id, 'cancelled')} data-testid={`button-cancel-booking-${b.id}`}>Cancel</button></> : <span className="muted-cell">No actions</span>}</div></td></tr>)}</tbody></table></div>
    </QueryState></Panel>
  </>;
}

function Support() {
  const qc = useQueryClient();
  const query = useListTickets();
  const create = useCreateTicket();
  const update = useUpdateTicket();
  const escalate = useEscalateTicket();
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(() => new URLSearchParams(window.location.search).get('new') === '1');
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const list = (query.data ?? []).filter(t => `${t.name} ${t.issue} ${t.status} ${t.priority}`.toLowerCase().includes(search.toLowerCase()));
  const refresh = () => { void qc.invalidateQueries({ queryKey: getListTicketsQueryKey() }); void qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); void qc.invalidateQueries({ queryKey: getListActivityQueryKey() }); };
  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget); setError(''); setNotice('');
    const data: TicketInput = { name: String(f.get('name')), phone: String(f.get('phone')), email: String(f.get('email') || '') || null, issue: String(f.get('issue')), priority: String(f.get('priority') || 'normal') as TicketInput['priority'], escalated: f.get('escalated') === 'on' };
    create.mutate({ data }, { onSuccess: () => { setNotice('Support case created. Your team can now track it here.'); setShowForm(false); refresh(); }, onError: () => setError('The support case could not be created. Please try again.') });
  }
  function setStatus(id: number, status: 'in_progress' | 'resolved') {
    setError(''); update.mutate({ ticketId: id, data: { status } }, { onSuccess: refresh, onError: () => setError('Ticket status could not be updated.') });
  }
  function escalateTicket(id: number) {
    setError(''); escalate.mutate({ ticketId: id }, { onSuccess: refresh, onError: () => setError('This ticket could not be escalated. Please retry.') });
  }
  return <>
    <PageTitle eyebrow="CUSTOMER CARE" title="Support, with a human in the loop." description="Track customer issues and escalate cases that need personal attention." action={<button className="button button-primary" onClick={() => { setShowForm(true); setError(''); }} data-testid="button-new-ticket"><MessageSquareText size={16} />New support case</button>} />
    <div className="support-summary"><div className="support-summary-icon"><Headset size={20} /></div><div><strong>{(query.data ?? []).filter(t => t.status === 'open' || t.status === 'in_progress').length} active cases</strong><span>Escalation flags a case for human follow-up; no live agent is notified.</span></div><div className="support-priority"><span className="priority-dot" />Human follow-through matters</div></div>
    {error && <InlineAlert text={error} />}{notice && <InlineSuccess text={notice} />}
    <div className="list-toolbar"><label className="search-field"><Search size={17} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search customer, issue, or status" aria-label="Search support tickets" data-testid="input-ticket-search" /></label><span className="toolbar-hint">Cases are private to your workspace</span></div>
    <Panel className="table-panel"><QueryState loading={query.isLoading} error={query.isError} retry={() => void query.refetch()} hasData={list.length > 0} empty={<EmptyState icon={Headset} title={search ? 'No cases match your search' : 'No support cases yet'} copy={search ? 'Try searching a different customer or issue.' : 'Customer support cases will appear here when submitted.'} action={search ? <button className="button button-secondary button-small" onClick={() => setSearch('')} data-testid="button-clear-ticket-search">Clear search</button> : <button className="button button-soft button-small" onClick={() => setShowForm(true)} data-testid="button-create-first-ticket">Create a case</button>} />}>
      <div className="table-scroll"><table className="tickets-table"><thead><tr><th>Case</th><th>Customer</th><th>Priority</th><th>Status</th><th>Actions</th></tr></thead><tbody>{list.map(t => <tr key={t.id} data-testid={`ticket-row-${t.id}`}><td><div className="ticket-table-issue"><div className={`ticket-mark ${t.priority === 'urgent' || t.priority === 'high' ? 'ticket-mark-high' : ''}`}><MessageSquareText size={16} /></div><div className="ticket-table-copy"><div className="ticket-title-row"><strong>{t.issue}</strong>{t.escalated && <span className="escalated-label"><Headset size={12} />Escalated</span>}</div><span>{dateLabel(t.createdAt)}</span></div></div></td><td><div className="table-person"><div className="person-initials">{t.name.split(' ').map(w => w[0]).slice(0,2).join('').toUpperCase()}</div><div><strong>{t.name}</strong><span>{t.phone}{t.email ? ` · ${t.email}` : ''}</span></div></div></td><td><span className="ticket-priority"><i className={`priority-bullet priority-${t.priority}`} />{t.priority}</span></td><td><StatusPill tone={t.status === 'resolved' || t.status === 'closed' ? 'pill-green' : t.status === 'in_progress' ? 'pill-blue' : 'pill-gold'}>{t.status.replace('_', ' ')}</StatusPill></td><td><div className="table-actions">{t.status === 'open' && <button className="text-action" onClick={() => setStatus(t.id, 'in_progress')} disabled={update.isPending} data-testid={`button-progress-ticket-${t.id}`}>Start</button>}{t.status !== 'resolved' && t.status !== 'closed' && <button className="text-action" onClick={() => setStatus(t.id, 'resolved')} disabled={update.isPending} data-testid={`button-resolve-ticket-${t.id}`}>Resolve</button>}{!t.escalated && t.status !== 'resolved' && t.status !== 'closed' && <button className="text-action text-teal" onClick={() => escalateTicket(t.id)} disabled={escalate.isPending} data-testid={`button-escalate-ticket-${t.id}`}>Escalate</button>}{(t.status === 'resolved' || t.status === 'closed') && <span className="muted-cell">—</span>}</div></td></tr>)}</tbody></table></div>
    </QueryState></Panel>
    {showForm && <FormModal title="Create a support case" subtitle="Capture the customer’s issue for your team." close={() => setShowForm(false)}><form className="modal-form" onSubmit={submit}><Field label="Customer name" name="name" required placeholder="Full name" /><Field label="Phone number" name="phone" required placeholder="+1 (555) 000-0000" /><Field label="Email address" name="email" type="email" placeholder="name@example.com" /><label className="field-label">Issue description<textarea name="issue" required minLength={5} rows={3} placeholder="What does the customer need help with?" data-testid="input-ticket-issue" /></label><label className="field-label">Priority<select name="priority" defaultValue="normal" data-testid="select-ticket-priority"><option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></label><label className="escalation-option"><input type="checkbox" name="escalated" data-testid="input-ticket-escalated" /><span><strong>Flag for human follow-up</strong><small>This marks the case for a person; it does not send a notification.</small></span></label><div className="modal-foot"><button type="button" className="button button-secondary" onClick={() => setShowForm(false)} data-testid="button-cancel-ticket">Cancel</button><button type="submit" disabled={create.isPending} className="button button-primary" data-testid="button-submit-ticket">{create.isPending ? 'Creating…' : 'Create case'}</button></div></form>{create.isError && <InlineAlert text="Could not create the case." />}</FormModal>}
  </>;
}

function ActivityPage() {
  const query = useListActivity({ limit: 100 });
  const [filter, setFilter] = useState('all');
  const list = (query.data ?? []).filter(a => filter === 'all' || a.outcome === filter);
  return <>
    <PageTitle eyebrow="AUDIT TRAIL" title="A clear record of every step." description="Follow customer actions and operational outcomes across your workspace." action={<span className="count-badge"><ActivityIcon size={15} />{query.data?.length ?? '—'} events</span>} />
    <div className="timeline-topline"><div><span className="live-indicator" />Persistent activity timeline</div><div className="filter-tabs compact-tabs">{['all','success','failed'].map(f => <button key={f} className={filter === f ? 'filter-tab active-tab' : 'filter-tab'} onClick={() => setFilter(f)} data-testid={`button-filter-activity-${f}`}>{f === 'all' ? 'All events' : f}</button>)}</div></div>
    <Panel className="timeline-panel"><QueryState loading={query.isLoading} error={query.isError} retry={() => void query.refetch()} hasData={list.length > 0} empty={<EmptyState icon={ActivityIcon} title="No actions in the timeline yet" copy="When your workspace saves an inquiry, visit request, or case, the action appears here." />}>
      <div className="timeline-list">{list.map((a, i) => <div className="timeline-row" key={a.id} data-testid={`timeline-event-${a.id}`}><div className="timeline-time"><strong>{shortDate(a.createdAt)}</strong><span>{new Date(a.createdAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span></div><div className="timeline-line"><span className={`timeline-dot ${a.outcome === 'failed' ? 'timeline-dot-fail' : ''}`} /></div><div className="timeline-copy"><div><strong>{a.description}</strong><StatusPill tone={a.outcome === 'failed' ? 'pill-red' : 'pill-green'}>{a.outcome}</StatusPill></div><span className="timeline-event-type">{a.eventType}</span></div><div className="timeline-id">EVENT {String(a.id).padStart(4, '0')}</div></div>)}</div>
    </QueryState></Panel>
    <div className="timeline-foot"><ShieldCheck size={15} /><span>Actions shown are returned by your connected operations API. No events are fabricated.</span></div>
  </>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Shell><Switch>
    <Route path="/" component={Overview} />
    <Route path="/properties" component={Properties} />
    <Route path="/assistant" component={Assistant} />
    <Route path="/leads" component={Leads} />
    <Route path="/bookings" component={Bookings} />
    <Route path="/support" component={Support} />
    <Route path="/activity" component={ActivityPage} />
    <Route component={NotFound} />
  </Switch></Shell></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
