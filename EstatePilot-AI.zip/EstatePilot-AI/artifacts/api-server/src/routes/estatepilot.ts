import { and, asc, count, desc, eq, gte, ilike, lte, notInArray } from "drizzle-orm";
import {
  Router,
  type IRouter,
  type NextFunction,
  type Request,
  type Response,
} from "express";
import {
  AssistantMessage,
  CreateBookingBody,
  CreateBookingResponse,
  CreateLeadBody,
  CreateLeadResponse,
  CreateTicketBody,
  CreateTicketResponse,
  DashboardSummary,
  EscalateTicketParams,
  EscalateTicketResponse,
  GetDashboardSummaryResponse,
  ListActivityQueryParams,
  ListActivityResponse,
  ListBookingsResponse,
  ListLeadsResponse,
  ListPropertiesQueryParams,
  ListPropertiesResponse,
  ListTicketsResponse,
  Property,
  SendAssistantMessageBody,
  SendAssistantMessageResponse,
  UpdateBookingBody,
  UpdateBookingParams,
  UpdateBookingResponse,
  UpdateTicketBody,
  UpdateTicketParams,
  UpdateTicketResponse,
} from "@workspace/api-zod";
import {
  activityTable,
  bookingsTable,
  db,
  leadsTable,
  propertiesTable,
  ticketsTable,
} from "@workspace/db";

const router: IRouter = Router();

async function recordFailedAction(req: Request, description: string): Promise<void> {
  try {
    await db.insert(activityTable).values({
      eventType: "action_failed",
      description,
      outcome: "failed",
    });
  } catch (error) {
    req.log.warn({ err: error }, "Could not record failed action outcome");
  }
}

async function sendValidationError(req: Request, res: Response, message: string): Promise<void> {
  await recordFailedAction(req, `Request ${req.method} ${req.path} was not saved because validation failed.`);
  res.status(400).json({ error: message });
}

router.get("/properties", async (req, res): Promise<void> => {
  const parsed = ListPropertiesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    await sendValidationError(req, res, parsed.error.message);
    return;
  }

  const { location, minBudget, maxBudget, bedrooms, propertyType } = parsed.data;
  const conditions = [];
  if (location?.trim()) conditions.push(ilike(propertiesTable.location, `%${location.trim()}%`));
  if (minBudget !== undefined) conditions.push(gte(propertiesTable.price, minBudget));
  if (maxBudget !== undefined) conditions.push(lte(propertiesTable.price, maxBudget));
  if (bedrooms !== undefined) conditions.push(gte(propertiesTable.bedrooms, bedrooms));
  if (propertyType?.trim()) conditions.push(ilike(propertiesTable.propertyType, propertyType.trim()));

  const records = await db
    .select()
    .from(propertiesTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(asc(propertiesTable.price));

  if (location || minBudget !== undefined || maxBudget !== undefined || bedrooms !== undefined || propertyType) {
    await db.insert(activityTable).values({
      eventType: "property_search",
      description: "Searched fictional demo listings with filters.",
      outcome: "success",
    });
  }

  res.json(ListPropertiesResponse.parse(records));
});

router.post("/assistant/messages", async (req, res): Promise<void> => {
  const parsed = SendAssistantMessageBody.safeParse(req.body);
  if (!parsed.success) {
    await sendValidationError(req, res, parsed.error.message);
    return;
  }

  const message = parsed.data.message.trim();
  const normalized = message.toLowerCase();
  const listings = await db.select().from(propertiesTable).orderBy(asc(propertiesTable.price));
  const knownLocations = [...new Set(listings.map((property) => property.location))];
  const knownPropertyTypes = [...new Set(listings.map((property) => property.propertyType))];
  const matchedLocation = knownLocations.find((location) => {
    const city = location.split(",")[0]?.trim().toLowerCase();
    return normalized.includes(location.toLowerCase()) || (!!city && normalized.includes(city));
  });
  const matchedPropertyType = knownPropertyTypes.find((type) => normalized.includes(type.toLowerCase()));
  const directProperty = listings.find(
    (property) =>
      normalized.includes(property.id.toLowerCase()) ||
      normalized.includes(property.title.toLowerCase()),
  );

  const bedroomMatch = normalized.match(/\b(\d+)\s*(?:br|beds?|bedrooms?)\b/);
  const bedrooms = bedroomMatch ? Number(bedroomMatch[1]) : undefined;
  const budgetMatch =
    normalized.match(/(?:under|below|up to|max(?:imum)?|budget(?: of)?)\s*\$?\s*([\d,.]+)\s*(k|m)?/i) ??
    normalized.match(/\$\s*([\d,.]+)\s*(k|m)\b/i);
  let maxBudget: number | undefined;
  if (budgetMatch) {
    const rawAmount = Number(budgetMatch[1].replace(/,/g, ""));
    const suffix = budgetMatch[2]?.toLowerCase();
    if (Number.isFinite(rawAmount)) {
      maxBudget = rawAmount * (suffix === "m" ? 1_000_000 : suffix === "k" ? 1_000 : 1);
    }
  }

  const isPropertySearch =
    /\b(find|search|show|looking|property|properties|home|homes|house|houses|bedroom|bedrooms|budget|under)\b/.test(
      normalized,
    ) || !!matchedLocation || !!matchedPropertyType || !!directProperty;

  let reply: string;
  let followUpQuestion: string | null = null;
  let matchedProperties: Property[] = [];
  let suggestions = ["Browse properties", "Request a visit", "Create support ticket"];

  if (directProperty) {
    matchedProperties = [directProperty];
    reply = `${directProperty.title} is a fictional demo ${directProperty.propertyType.toLowerCase()} in ${directProperty.location}, listed at ${new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(directProperty.price)} with ${directProperty.bedrooms} bedrooms. ${directProperty.description}`;
    followUpQuestion = "Would you like to save an inquiry or request a visit?";
    suggestions = ["Request a visit", "Save my search"];
    await db.insert(activityTable).values({
      eventType: "property_search",
      description: "Assistant viewed a fictional demo listing.",
      outcome: "success",
    });
  } else if (isPropertySearch) {
    const conditions = [];
    if (matchedLocation) conditions.push(ilike(propertiesTable.location, `%${matchedLocation.split(",")[0]}%`));
    if (maxBudget !== undefined) conditions.push(lte(propertiesTable.price, maxBudget));
    if (bedrooms !== undefined) conditions.push(gte(propertiesTable.bedrooms, bedrooms));
    if (matchedPropertyType) conditions.push(ilike(propertiesTable.propertyType, matchedPropertyType));
    const results = await db
      .select()
      .from(propertiesTable)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(asc(propertiesTable.price))
      .limit(4);
    matchedProperties = results;
    if (!matchedLocation) {
      followUpQuestion = "Which city or neighborhood should I search?";
    } else if (maxBudget === undefined) {
      followUpQuestion = "What budget range should I use to narrow the results?";
    } else if (bedrooms === undefined) {
      followUpQuestion = "How many bedrooms would you like?";
    } else if (matchedPropertyType === undefined) {
      followUpQuestion = "Do you prefer a house, condo, townhouse, apartment, or another type?";
    }
    reply = results.length
      ? `I found ${results.length} fictional demo ${results.length === 1 ? "listing" : "listings"}${matchedLocation ? ` in ${matchedLocation}` : ""}${maxBudget !== undefined ? ` under ${new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(maxBudget)}` : ""}. These results come only from the demo property records.`
      : "I couldn't find a demo listing matching those details. Try a different city, budget, or bedroom count.";
    suggestions = ["Show all properties", "Request a visit", "Save my search"];
    await db.insert(activityTable).values({
      eventType: "property_search",
      description: "Assistant searched fictional demo listings.",
      outcome: "success",
    });
  } else if (/\b(human|agent|person|speak to|talk to|representative)\b/.test(normalized)) {
    reply =
      "I can help create a support ticket and mark it for human follow-up. This demo does not send notifications or connect to a live agent.";
    followUpQuestion = "What would you like the support team to help with?";
    suggestions = ["Create support ticket"];
  } else if (/\b(visit|tour|showing|appointment|schedule|book)\b/.test(normalized)) {
    reply =
      "You can request a visit for an available demo property. The request is saved with a “requested” status; no real appointment or notification is created.";
    followUpQuestion = "Which property would you like to visit, and what date and time work for you?";
    suggestions = ["Request a visit", "Browse properties"];
  } else if (/\b(real|fictional|demo|actual listings)\b/.test(normalized)) {
    reply =
      "Every property shown in EstatePilot AI is a fictional demo listing. The app does not connect to a real estate inventory feed.";
    suggestions = ["Browse properties", "How do visit requests work?"];
  } else if (/\b(fee|fees|commission|closing cost|financing|mortgage|school|schools|pet|pets)\b/.test(normalized)) {
    reply =
      "That detail is not included in the demo property records, so I don't want to guess. Please create a support ticket if you'd like a human follow-up.";
    suggestions = ["Create support ticket", "Browse properties"];
  } else {
    reply =
      "I can search the fictional demo listings, explain how visit requests work, or help create a support ticket. Tell me a city, budget, and bedroom count to start a search.";
    followUpQuestion = "What would you like help with?";
  }

  const response: AssistantMessage = {
    reply,
    matchedProperties,
    followUpQuestion,
    suggestions,
    mode: "Demo assistant",
  };
  res.json(SendAssistantMessageResponse.parse(response));
});

router.get("/leads", async (_req, res): Promise<void> => {
  const records = await db.select().from(leadsTable).orderBy(desc(leadsTable.createdAt));
  res.json(ListLeadsResponse.parse(records));
});

router.post("/leads", async (req, res): Promise<void> => {
  const parsed = CreateLeadBody.safeParse(req.body);
  if (!parsed.success) {
    await sendValidationError(req, res, parsed.error.message);
    return;
  }

  const values = {
    ...parsed.data,
    name: parsed.data.name.trim(),
    phone: parsed.data.phone.trim(),
    email: parsed.data.email?.trim() || null,
    preferredLocation: parsed.data.preferredLocation.trim(),
    propertyInterest: parsed.data.propertyInterest?.trim() || null,
  };
  const lead = await db.transaction(async (tx) => {
    const [created] = await tx.insert(leadsTable).values(values).returning();
    if (!created) throw new Error("Lead was not returned after insert");
    await tx.insert(activityTable).values({
      eventType: "lead_created",
      description: "Lead saved to the customer workspace.",
      outcome: "success",
    });
    return created;
  });

  res.status(201).json(CreateLeadResponse.parse(lead));
});

router.get("/bookings", async (_req, res): Promise<void> => {
  const records = await db.select().from(bookingsTable).orderBy(desc(bookingsTable.createdAt));
  res.json(ListBookingsResponse.parse(records));
});

router.post("/bookings", async (req, res): Promise<void> => {
  const parsed = CreateBookingBody.safeParse(req.body);
  if (!parsed.success) {
    await sendValidationError(req, res, parsed.error.message);
    return;
  }

  const property = await db
    .select({ id: propertiesTable.id, availability: propertiesTable.availability })
    .from(propertiesTable)
    .where(eq(propertiesTable.id, parsed.data.propertyId))
    .limit(1);
  if (!property[0]) {
    await sendValidationError(req, res, "Choose a property from the demo listings.");
    return;
  }
  if (property[0].availability.toLowerCase() !== "available") {
    await sendValidationError(req, res, "This property is not currently available for a visit request.");
    return;
  }
  const preferredDate = parsed.data.preferredDate.toISOString().slice(0, 10);
  if (preferredDate < new Date().toISOString().slice(0, 10)) {
    await sendValidationError(req, res, "Choose today or a future date.");
    return;
  }

  const values = {
    ...parsed.data,
    name: parsed.data.name.trim(),
    phone: parsed.data.phone.trim(),
    email: parsed.data.email?.trim() || null,
    preferredDate,
    preferredTime: parsed.data.preferredTime.trim(),
    status: "requested",
  };
  const booking = await db.transaction(async (tx) => {
    const [created] = await tx.insert(bookingsTable).values(values).returning();
    if (!created) throw new Error("Visit request was not returned after insert");
    await tx.insert(activityTable).values({
      eventType: "booking_requested",
      description: `Visit requested for ${created.propertyId}.`,
      outcome: "success",
    });
    return created;
  });

  res.status(201).json(CreateBookingResponse.parse(booking));
});

router.patch("/bookings/:bookingId", async (req, res): Promise<void> => {
  const params = UpdateBookingParams.safeParse(req.params);
  const parsed = UpdateBookingBody.safeParse(req.body);
  if (!params.success) {
    await sendValidationError(req, res, params.error.message);
    return;
  }
  if (!parsed.success) {
    await sendValidationError(req, res, parsed.error.message);
    return;
  }

  const updated = await db.transaction(async (tx) => {
    const [booking] = await tx
      .update(bookingsTable)
      .set({ status: parsed.data.status })
      .where(eq(bookingsTable.id, params.data.bookingId))
      .returning();
    if (!booking) return null;
    await tx.insert(activityTable).values({
      eventType: `booking_${parsed.data.status}`,
      description: `Visit request #${booking.id} marked ${parsed.data.status}.`,
      outcome: "success",
    });
    return booking;
  });
  if (!updated) {
    await recordFailedAction(req, "A visit status update failed because the request was not found.");
    res.status(404).json({ error: "Visit request not found." });
    return;
  }
  res.json(UpdateBookingResponse.parse(updated));
});

router.get("/tickets", async (_req, res): Promise<void> => {
  const records = await db.select().from(ticketsTable).orderBy(desc(ticketsTable.createdAt));
  res.json(ListTicketsResponse.parse(records));
});

router.post("/tickets", async (req, res): Promise<void> => {
  const parsed = CreateTicketBody.safeParse(req.body);
  if (!parsed.success) {
    await sendValidationError(req, res, parsed.error.message);
    return;
  }

  const values = {
    ...parsed.data,
    name: parsed.data.name.trim(),
    phone: parsed.data.phone.trim(),
    email: parsed.data.email?.trim() || null,
    issue: parsed.data.issue.trim(),
    escalated: parsed.data.escalated ?? false,
    status: "open",
  };
  const ticket = await db.transaction(async (tx) => {
    const [created] = await tx.insert(ticketsTable).values(values).returning();
    if (!created) throw new Error("Ticket was not returned after insert");
    await tx.insert(activityTable).values({
      eventType: "ticket_created",
      description: `Support ticket #${created.id} created.`,
      outcome: "success",
    });
    if (created.escalated) {
      await tx.insert(activityTable).values({
        eventType: "ticket_escalated",
        description: `Support ticket #${created.id} escalated for human follow-up.`,
        outcome: "success",
      });
    }
    return created;
  });
  res.status(201).json(CreateTicketResponse.parse(ticket));
});

router.patch("/tickets/:ticketId", async (req, res): Promise<void> => {
  const params = UpdateTicketParams.safeParse(req.params);
  const parsed = UpdateTicketBody.safeParse(req.body);
  if (!params.success) {
    await sendValidationError(req, res, params.error.message);
    return;
  }
  if (!parsed.success) {
    await sendValidationError(req, res, parsed.error.message);
    return;
  }

  const updated = await db.transaction(async (tx) => {
    const [ticket] = await tx
      .update(ticketsTable)
      .set(parsed.data)
      .where(eq(ticketsTable.id, params.data.ticketId))
      .returning();
    if (!ticket) return null;
    await tx.insert(activityTable).values({
      eventType: "ticket_updated",
      description: `Support ticket #${ticket.id} updated.`,
      outcome: "success",
    });
    return ticket;
  });
  if (!updated) {
    await recordFailedAction(req, "A ticket update failed because the support case was not found.");
    res.status(404).json({ error: "Support ticket not found." });
    return;
  }
  res.json(UpdateTicketResponse.parse(updated));
});

router.post("/tickets/:ticketId/escalate", async (req, res): Promise<void> => {
  const params = EscalateTicketParams.safeParse(req.params);
  if (!params.success) {
    await sendValidationError(req, res, params.error.message);
    return;
  }
  const updated = await db.transaction(async (tx) => {
    const [existing] = await tx
      .select({ id: ticketsTable.id, escalated: ticketsTable.escalated })
      .from(ticketsTable)
      .where(eq(ticketsTable.id, params.data.ticketId));
    if (!existing) return null;
    const [ticket] = await tx
      .update(ticketsTable)
      .set({ escalated: true })
      .where(eq(ticketsTable.id, params.data.ticketId))
      .returning();
    if (!ticket) return null;
    if (!existing.escalated) {
      await tx.insert(activityTable).values({
        eventType: "ticket_escalated",
        description: `Support ticket #${ticket.id} escalated for human follow-up.`,
        outcome: "success",
      });
    }
    return ticket;
  });
  if (!updated) {
    await recordFailedAction(req, "A human escalation failed because the support case was not found.");
    res.status(404).json({ error: "Support ticket not found." });
    return;
  }
  res.json(EscalateTicketResponse.parse(updated));
});

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const [[leads], [visits], [open], [escalated]] = await Promise.all([
    db.select({ value: count() }).from(leadsTable),
    db.select({ value: count() }).from(bookingsTable),
    db
      .select({ value: count() })
      .from(ticketsTable)
      .where(notInArray(ticketsTable.status, ["resolved", "closed"])),
    db.select({ value: count() }).from(ticketsTable).where(eq(ticketsTable.escalated, true)),
  ]);
  const data: DashboardSummary = {
    totalLeads: leads?.value ?? 0,
    visitRequests: visits?.value ?? 0,
    openTickets: open?.value ?? 0,
    escalatedCases: escalated?.value ?? 0,
  };
  res.json(GetDashboardSummaryResponse.parse(data));
});

router.get("/activity", async (req, res): Promise<void> => {
  const parsed = ListActivityQueryParams.safeParse(req.query);
  if (!parsed.success) {
    await sendValidationError(req, res, parsed.error.message);
    return;
  }
  const records = await db
    .select()
    .from(activityTable)
    .orderBy(desc(activityTable.createdAt))
    .limit(parsed.data.limit ?? 30);
  res.json(ListActivityResponse.parse(records));
});

router.use(async (error: unknown, req: Request, res: Response, next: NextFunction) => {
  req.log.error({ err: error }, "EstatePilot API request failed");
  await recordFailedAction(req, `Request ${req.method} ${req.path} failed before it could be confirmed.`);
  if (res.headersSent) {
    next(error);
    return;
  }
  res.status(500).json({ error: "The request could not be completed. Please try again." });
});

export default router;
