# EstatePilot AI

Responsive real-estate customer operations dashboard with fictional property listings, lead capture, visit requests, support cases, and an auditable activity timeline.

## Run & Operate

- Start the configured `artifacts/estatepilot-ai: web` and `artifacts/api-server: API Server` workflows to run the app and its API.
- `pnpm --filter @workspace/estatepilot-ai run dev` — run the Vite frontend
- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- The API uses the workspace PostgreSQL `DATABASE_URL`. No external AI or listing-provider API key is used.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- Web: React + Vite
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/estatepilot-ai/src/App.tsx` and `src/index.css` — dashboard and customer-facing flows
- `artifacts/api-server/src/routes/estatepilot.ts` — EstatePilot API handlers and demo assistant
- `lib/api-spec/openapi.yaml` — API contract; generated hooks and validators are under `lib/`
- `lib/db/src/schema/` — PostgreSQL table definitions

## Architecture decisions

- All properties are clearly labeled fictional demo listings; no external listing feed is connected.
- The assistant uses deterministic rules and saved demo property records, not a live LLM.
- Visit requests are saved as `requested`; confirming a record does not create a calendar event or notify a customer.
- Escalation is a workspace flag only; no live agent or notification provider is connected.

## Product

- Operations overview with live database counts, recent visit requests, activity, and manual refresh.
- Searchable property catalog with location, type, maximum budget, and minimum-bedroom filters.
- Customer assistant with listing matches and lead/visit/support flows.
- Lead, visit-request, support-case, and activity pages with status management and database persistence.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Demo contact details and properties are fictional. Do not present them as real listings or customers.
- Assistant answers, calendar handling, and human escalation are demo-only and do not use external providers.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
