---
name: Generated fetch client TypeScript libraries
description: TypeScript library requirements for the generated Orval fetch client.
---

**Rule:** Keep `dom.iterable` in the TypeScript `lib` list for `lib/api-client-react`.

**Why:** The generated fetch helpers use `Headers.entries()`. Without the iterable DOM declarations, code generation can succeed but the chained client typecheck fails.

**How to apply:** If generated client typechecking reports that `Headers.entries` is missing, check the client TypeScript library declarations before editing generated output.
