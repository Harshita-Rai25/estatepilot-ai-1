import { pgTable, text, integer, numeric, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const propertiesTable = pgTable("estatepilot_properties", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  location: text("location").notNull(),
  price: numeric("price", { precision: 14, scale: 2, mode: "number" }).notNull(),
  bedrooms: integer("bedrooms").notNull(),
  propertyType: text("property_type").notNull(),
  description: text("description").notNull(),
  availability: text("availability").notNull().default("Available"),
  fictional: boolean("fictional").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertPropertySchema = createInsertSchema(propertiesTable).omit({
  createdAt: true,
});
export type InsertProperty = z.infer<typeof insertPropertySchema>;
export type Property = typeof propertiesTable.$inferSelect;
